bl_info = {
    "name": "Task Leveler",
    "author": "Elite",
    "version": (0, 75, 0),
    "blender": (3, 0, 0),
    "location": "Status Bar (always on) + bottom-center viewport HUD + View3D > Sidebar > Tasks (editor)",
    "description": "Turn your blender projects into a rewarding game where you earn XP completing tasks, level up, and keeping track of your progress with frequent check-ins to keep you on top of your projects. *DISCLAIMER* - AI tools were used to help develop this utility",
    "category": "3D View",
}

import bpy
import blf
import gpu
import os
import time
from gpu_extras.batch import batch_for_shader
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    EnumProperty,
    CollectionProperty,
    PointerProperty,
    FloatVectorProperty,
)
from bpy.types import PropertyGroup, Panel, Operator, UIList

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

DIFFICULTY_XP = {
    'EASY': 5,
    'MEDIUM': 10,
    'HARD': 20,
    'BOSS': 40,
}

DIFFICULTY_ITEMS = (
    ('EASY', "Easy", "Quick win, 5 XP"),
    ('MEDIUM', "Medium", "Standard task, 10 XP"),
    ('HARD', "Hard", "Tough task, 20 XP"),
    ('BOSS', "Boss Fight", "Major milestone, 40 XP"),
)

MICROTASK_XP = 3
XP_PER_LEVEL = 50  # base XP required per level; ramps up each level

ACCENT_COLOR = (1.0, 0.75, 0.15, 0.95)       # gold accent: top strip + filled progress
BG_COLOR = (0.07, 0.07, 0.08, 0.62)          # HUD panel background
TRACK_COLOR = (1.0, 1.0, 1.0, 0.12)          # progress bar empty track

_nudge_timer_active = False
_hud_handle = None
_rect_shader = None
_hud_anim = None
_HUD_ANIM_DURATION = 0.82


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

class TASKLEVELER_Microtask(PropertyGroup):
    name: StringProperty(name="Microtask", default="New Microtask")
    done: BoolProperty(name="Done", default=False)
    xp_value: IntProperty(default=MICROTASK_XP)


class TASKLEVELER_Task(PropertyGroup):
    name: StringProperty(name="Task", default="New Task")
    done: BoolProperty(name="Done", default=False)
    hidden: BoolProperty(name="Hidden", default=False)
    difficulty: StringProperty(default="MEDIUM")
    xp_value: IntProperty(default=10)
    microtasks: CollectionProperty(type=TASKLEVELER_Microtask)
    active_microtask_index: IntProperty(default=0)
    new_microtask_name: StringProperty(name="New Microtask", default="")


class TASKLEVELER_Settings(PropertyGroup):
    tasks: CollectionProperty(type=TASKLEVELER_Task)
    active_index: IntProperty(default=0)
    total_xp: IntProperty(default=0)

    new_task_name: StringProperty(name="New Task", default="")
    new_task_difficulty: EnumProperty(
        name="Difficulty", items=DIFFICULTY_ITEMS, default='MEDIUM'
    )

    show_hidden: BoolProperty(name="Show Hidden Tasks", default=False)

    sound_enabled: BoolProperty(name="Sound Cues", default=True)
    custom_tick_sound: StringProperty(
        name="Tick Sound", subtype='FILE_PATH', default="",
        description="Optional audio file path for task/microtask completion. Example: //sounds/task_tick.wav or C:/Sounds/task_tick.wav. Leave blank for the built-in tone."
    )
    custom_levelup_sound: StringProperty(
        name="Level-Up Sound", subtype='FILE_PATH', default="",
        description="Optional audio file path for leveling up. Example: //sounds/level_up.wav or C:/Sounds/level_up.wav. Leave blank for the built-in chime."
    )
    custom_project_complete_sound: StringProperty(
        name="Project Complete Sound", subtype='FILE_PATH', default="",
        description="Optional audio file played when every task in this scene is complete. Example: //sounds/project_complete.wav. Leave blank for the built-in celebratory tones."
    )

    nudges_enabled: BoolProperty(name="Focus Nudges", default=False)
    nudge_interval_minutes: IntProperty(
        name="Nudge Every (min)", default=25, min=5, max=120
    )

    hud_enabled: BoolProperty(
        name="Viewport HUD", default=False,
        description="Show or hide the level/XP bar at the bottom-center of the 3D Viewport"
    )


class TASKLEVELER_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    hud_progress_color: FloatVectorProperty(
        name="Viewport Progress Colour",
        description="Global colour for the bottom-centre viewport HUD progress bar and accent strip; shared across all projects",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        # sRGB #2460FF converted to linear RGB for Blender's colour property.
        default=(0.0185, 0.11697, 1.0, 1.0),
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Shared across all Blender projects")
        layout.prop(self, "hud_progress_color", text="Progress Colour")


def get_global_progress_color():
    """Return the preference colour converted from Blender's linear RGB to sRGB.

    Blender's COLOR property stores linear RGB values, while the viewport HUD's
    GPU overlay is displayed without the same colour-management conversion as
    the colour picker. Convert RGB to sRGB here so the HUD visually matches the
    colour shown in the preferences. Alpha is passed through unchanged.
    """
    addon = bpy.context.preferences.addons.get(__package__)
    if addon is not None:
        color = tuple(addon.preferences.hud_progress_color)
    else:
        color = (0.0185, 0.11697, 1.0, 1.0)

    def linear_to_srgb(channel):
        channel = max(0.0, min(1.0, channel))
        if channel <= 0.0031308:
            return 12.92 * channel
        return 1.055 * (channel ** (1.0 / 2.4)) - 0.055

    return (
        linear_to_srgb(color[0]),
        linear_to_srgb(color[1]),
        linear_to_srgb(color[2]),
        color[3] if len(color) > 3 else 1.0,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_settings(context):
    return context.scene.task_leveler


def xp_for_level(level):
    return XP_PER_LEVEL + (level * 10)


def level_from_xp(total_xp):
    level = 1
    remaining = total_xp
    while remaining >= xp_for_level(level):
        remaining -= xp_for_level(level)
        level += 1
    return level, remaining, xp_for_level(level)


def tag_redraw_all(context):
    try:
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception:
        pass


def play_tone(frequency=880, duration=0.15, volume=0.4):
    try:
        import aud
        device = aud.Device()
        sound = aud.Sound.sine(frequency)
        sound = sound.limit(0, duration)
        handle = device.play(sound)
        handle.volume = volume
    except Exception:
        pass


def play_file(path, volume=0.5):
    try:
        import aud
        if not path:
            return False
        abs_path = bpy.path.abspath(path)
        if not os.path.isfile(abs_path):
            return False
        device = aud.Device()
        sound = aud.Sound.file(abs_path)
        handle = device.play(sound)
        handle.volume = volume
        return True
    except Exception:
        return False


def play_task_tick(settings):
    if not settings.sound_enabled:
        return
    if play_file(settings.custom_tick_sound, 0.5):
        return
    play_tone(520, 0.08, 0.25)


def play_level_up_chime(settings):
    if not settings.sound_enabled:
        return
    if play_file(settings.custom_levelup_sound, 0.6):
        return
    play_tone(660, 0.12, 0.4)
    play_tone(880, 0.12, 0.4)
    play_tone(1320, 0.18, 0.45)


def play_project_complete_sound(settings):
    """Play a distinct celebration when every top-level task is complete."""
    if not settings.sound_enabled:
        return
    if play_file(settings.custom_project_complete_sound, 0.7):
        return
    # Built-in ascending celebratory sequence, distinct from the task tick/level-up cue.
    play_tone(523, 0.12, 0.4)
    play_tone(659, 0.12, 0.4)
    play_tone(784, 0.12, 0.4)
    play_tone(1047, 0.28, 0.5)


def check_project_completion(settings):
    """Return True and play the celebration when a non-empty task list is fully complete."""
    if len(settings.tasks) > 0 and all(task.done for task in settings.tasks):
        play_project_complete_sound(settings)
        return True
    return False


def start_hud_progress_animation(old_total_xp, new_total_xp):
    """Animate the viewport XP bar after XP changes, including a level-up reset."""
    global _hud_anim
    old_level, old_into, old_needed = level_from_xp(old_total_xp)
    new_level, new_into, new_needed = level_from_xp(new_total_xp)
    old_frac = old_into / old_needed if old_needed else 0.0
    new_frac = new_into / new_needed if new_needed else 0.0
    if new_level > old_level:
        # Fill the old level, briefly reset, then fill toward the new level's progress.
        frames = [(0.0, old_frac), (0.34, 1.0), (0.42, 0.0), (_HUD_ANIM_DURATION, new_frac)]
    else:
        frames = [(0.0, old_frac), (_HUD_ANIM_DURATION, new_frac)]
    _hud_anim = {"start": time.monotonic(), "frames": frames}
    if not bpy.app.timers.is_registered(_hud_animation_tick):
        bpy.app.timers.register(_hud_animation_tick, first_interval=0.02)


def _hud_animation_tick():
    """Keep viewports repainting while the progress animation is running."""
    global _hud_anim
    if _hud_anim is None:
        return None
    if time.monotonic() - _hud_anim["start"] >= _HUD_ANIM_DURATION:
        _hud_anim = None
        try:
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
        except Exception:
            pass
        return None
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass
    return 0.02


def animated_hud_fraction(fallback):
    """Return the eased progress value for the current HUD animation, if any."""
    if _hud_anim is None:
        return fallback
    elapsed = min(max(time.monotonic() - _hud_anim["start"], 0.0), _HUD_ANIM_DURATION)
    frames = _hud_anim["frames"]
    for index in range(1, len(frames)):
        t1, v1 = frames[index]
        t0, v0 = frames[index - 1]
        if elapsed <= t1:
            span = max(t1 - t0, 0.0001)
            f = min(max((elapsed - t0) / span, 0.0), 1.0)
            # Smoothstep easing avoids a rigid, linear step-like movement.
            f = f * f * (3.0 - 2.0 * f)
            return v0 + (v1 - v0) * f
    return frames[-1][1]


def award_xp(context, settings, delta):
    """Apply an XP change, fire tick/level-up feedback, and return whether a level-up occurred."""
    old_total_xp = settings.total_xp
    level_before, _, _ = level_from_xp(old_total_xp)
    settings.total_xp = max(0, settings.total_xp + delta)
    level_after, _, _ = level_from_xp(settings.total_xp)
    start_hud_progress_animation(old_total_xp, settings.total_xp)

    if delta > 0:
        play_task_tick(settings)

    leveled_up = level_after > level_before
    if leveled_up:
        play_level_up_chime(settings)
        try:
            bpy.ops.taskleveler.celebrate('INVOKE_DEFAULT', message=f"LEVEL UP! Lv {level_after}")
        except Exception:
            pass

    tag_redraw_all(context)
    return leveled_up


def sync_parent_completion(context, settings, task):
    """If a task has microtasks, keep the parent's done state in sync with them."""
    if len(task.microtasks) == 0:
        return
    all_done = all(m.done for m in task.microtasks)
    if all_done and not task.done:
        task.done = True
        award_xp(context, settings, task.xp_value)
    elif not all_done and task.done:
        task.done = False
        award_xp(context, settings, -task.xp_value)


# ---------------------------------------------------------------------------
# Level-up screen flash
# ---------------------------------------------------------------------------

def _draw_level_up(message, start_time, duration):
    elapsed = time.time() - start_time
    if elapsed > duration:
        return
    fade = max(0.0, 1.0 - (elapsed / duration))
    font_id = 0
    region = bpy.context.region
    if region is None:
        return
    x = region.width * 0.5 - 140
    y = region.height * 0.6
    blf.size(font_id, 42)
    try:
        blf.color(font_id, 1.0, 0.85, 0.2, fade)
    except Exception:
        pass
    blf.position(font_id, x, y, 0)
    blf.draw(font_id, message)


class TASKLEVELER_OT_celebrate(Operator):
    bl_idname = "taskleveler.celebrate"
    bl_label = "Level Up Flash"
    bl_options = {'INTERNAL'}

    message: StringProperty(default="LEVEL UP!")
    duration: bpy.props.FloatProperty(default=1.6)

    _timer = None
    _start = 0.0
    _handle = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            if time.time() - self._start > self.duration:
                self.cancel(context)
                return {'FINISHED'}
            if context.area:
                context.area.tag_redraw()
        return {'PASS_THROUGH'}

    def execute(self, context):
        self._start = time.time()
        args = (self.message, self._start, self.duration)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_level_up, args, 'WINDOW', 'POST_PIXEL'
        )
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.05, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if self._handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            self._handle = None
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        if context.area:
            context.area.tag_redraw()


# ---------------------------------------------------------------------------
# Always-on viewport HUD — bottom-center, drawn as a small styled panel
# ---------------------------------------------------------------------------

def _get_rect_shader():
    global _rect_shader
    if _rect_shader is None:
        for name in ('UNIFORM_COLOR', '2D_UNIFORM_COLOR'):
            try:
                _rect_shader = gpu.shader.from_builtin(name)
                break
            except Exception:
                continue
    return _rect_shader


def draw_rect(x0, y0, x1, y1, color):
    shader = _get_rect_shader()
    if shader is None:
        return
    vertices = ((x0, y0), (x1, y0), (x1, y1), (x0, y1))
    indices = ((0, 1, 2), (2, 3, 0))
    batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


def draw_centered_text(font_id, text, center_x, y, size, color):
    blf.size(font_id, size)
    try:
        blf.color(font_id, *color)
    except Exception:
        pass
    tw, th = blf.dimensions(font_id, text)
    blf.position(font_id, center_x - tw / 2, y, 0)
    blf.draw(font_id, text)


def draw_viewport_hud():
    context = bpy.context
    try:
        settings = context.scene.task_leveler
    except Exception:
        return
    if not settings.hud_enabled:
        return
    region = context.region
    if region is None:
        return

    level, xp_into, xp_needed = level_from_xp(settings.total_xp)
    frac = xp_into / xp_needed if xp_needed else 0
    frac = animated_hud_fraction(frac)

    box_w, box_h = 300, 78
    center_x = region.width / 2
    y0 = 36  # distance from bottom edge of the viewport
    y1 = y0 + box_h
    x0 = center_x - box_w / 2
    x1 = center_x + box_w / 2

    try:
        gpu.state.blend_set('ALPHA')
    except Exception:
        pass

    # panel background + user-configurable accent strip along the top edge
    progress_color = get_global_progress_color()
    draw_rect(x0, y0, x1, y1, BG_COLOR)
    draw_rect(x0, y1 - 3, x1, y1, progress_color)

    # progress bar track + fill
    bar_margin = 16
    bar_x0, bar_x1 = x0 + bar_margin, x1 - bar_margin
    bar_y0, bar_y1 = y0 + 12, y0 + 12 + 8
    draw_rect(bar_x0, bar_y0, bar_x1, bar_y1, TRACK_COLOR)
    if frac > 0:
        draw_rect(bar_x0, bar_y0, bar_x0 + (bar_x1 - bar_x0) * frac, bar_y1, progress_color)

    try:
        gpu.state.blend_set('NONE')
    except Exception:
        pass

    font_id = 0
    completed_tasks = sum(1 for task in settings.tasks if task.done)
    total_tasks = len(settings.tasks)
    draw_centered_text(font_id, f"LEVEL {level}", center_x, y1 - 22, 18, (1, 1, 1, 0.95))
    draw_centered_text(font_id, f"{completed_tasks} / {total_tasks} TASKS COMPLETED", center_x, y1 - 40, 11, (1, 1, 1, 0.82))
    draw_centered_text(font_id, f"{xp_into} / {xp_needed} XP", center_x, bar_y1 + 3, 11, (1, 1, 1, 0.7))


# ---------------------------------------------------------------------------
# Status bar (visible in every editor/workspace, always)
# ---------------------------------------------------------------------------

def draw_status_bar(self, context):
    try:
        settings = context.scene.task_leveler
    except Exception:
        return
    level, xp_into, xp_needed = level_from_xp(settings.total_xp)
    pct = int(100 * xp_into / xp_needed) if xp_needed else 0
    active = [t for t in settings.tasks if not t.done and not t.hidden]

    layout = self.layout
    layout.label(text=f"Lv {level}", icon='SOLO_ON')
    layout.label(text=f"{pct}% to next level")
    if active:
        layout.label(text=f"Next: {active[0].name}", icon='CHECKBOX_DEHLT')
    else:
        layout.label(text="All quests clear", icon='CHECKMARK')


# ---------------------------------------------------------------------------
# Task operators
# ---------------------------------------------------------------------------

class TASKLEVELER_OT_clear_sound_path(Operator):
    bl_idname = "taskleveler.clear_sound_path"
    bl_label = "Clear Sound Path"
    bl_description = "Clear the selected custom sound file path and use the built-in sound"

    sound_field: EnumProperty(
        name="Sound Field",
        items=(
            ('TICK', "Task / Microtask Sound", "Clear the task and microtask sound path"),
            ('LEVELUP', "Level-Up Sound", "Clear the level-up sound path"),
            ('PROJECT_COMPLETE', "Project Complete Sound", "Clear the project completion sound path"),
        ),
    )

    def execute(self, context):
        settings = get_settings(context)
        field_map = {
            'TICK': 'custom_tick_sound',
            'LEVELUP': 'custom_levelup_sound',
            'PROJECT_COMPLETE': 'custom_project_complete_sound',
        }
        field_name = field_map.get(self.sound_field)
        if not field_name:
            return {'CANCELLED'}
        setattr(settings, field_name, "")
        self.report({'INFO'}, "Custom sound path cleared; built-in sound will be used")
        tag_redraw_all(context)
        return {'FINISHED'}


class TASKLEVELER_OT_toggle_hud(Operator):
    bl_idname = "taskleveler.toggle_hud"
    bl_label = "Toggle Level UI"
    bl_description = "Show or hide the bottom-center level and XP display"

    def execute(self, context):
        settings = get_settings(context)
        settings.hud_enabled = not settings.hud_enabled
        tag_redraw_all(context)
        return {'FINISHED'}


class TASKLEVELER_OT_add_task(Operator):
    bl_idname = "taskleveler.add_task"
    bl_label = "Add Task"

    def execute(self, context):
        settings = get_settings(context)
        name = settings.new_task_name.strip()
        if not name:
            self.report({'WARNING'}, "Type a task name first")
            return {'CANCELLED'}
        task = settings.tasks.add()
        task.name = name
        # Automatically reveal the viewport HUD when the user starts adding tasks.
        settings.hud_enabled = True
        task.difficulty = settings.new_task_difficulty
        task.xp_value = DIFFICULTY_XP[settings.new_task_difficulty]
        settings.new_task_name = ""
        settings.active_index = len(settings.tasks) - 1
        return {'FINISHED'}


class TASKLEVELER_OT_remove_task(Operator):
    bl_idname = "taskleveler.remove_task"
    bl_label = "Remove Task"
    bl_description = "Delete this task and remove all XP earned from its completed task and microtasks"

    def execute(self, context):
        settings = get_settings(context)
        idx = settings.active_index
        if 0 <= idx < len(settings.tasks):
            task = settings.tasks[idx]
            # Remove every point attributable to this task before deleting it.
            # This includes the parent-task reward and any completed microtask rewards.
            earned_xp = (task.xp_value if task.done else 0)
            earned_xp += sum(micro.xp_value for micro in task.microtasks if micro.done)
            if earned_xp:
                award_xp(context, settings, -earned_xp)
            settings.tasks.remove(idx)
            settings.active_index = min(max(0, idx - 1), max(0, len(settings.tasks) - 1))
            tag_redraw_all(context)
        return {'FINISHED'}


class TASKLEVELER_OT_toggle_task(Operator):
    bl_idname = "taskleveler.toggle_task"
    bl_label = "Toggle Task"

    index: IntProperty()

    def execute(self, context):
        settings = get_settings(context)
        task = settings.tasks[self.index]
        task.done = not task.done
        delta = task.xp_value if task.done else -task.xp_value
        award_xp(context, settings, delta)
        if task.done:
            check_project_completion(settings)
        return {'FINISHED'}


class TASKLEVELER_OT_hide_done(Operator):
    bl_idname = "taskleveler.hide_done"
    bl_label = "Hide Completed"
    bl_description = "Toggle between hiding completed tasks and restoring all hidden tasks"

    def execute(self, context):
        settings = get_settings(context)
        hidden_count = sum(1 for task in settings.tasks if task.hidden)

        # If anything is hidden, this button restores hidden tasks.
        # Otherwise, it hides all currently completed tasks.
        if hidden_count:
            for task in settings.tasks:
                task.hidden = False
            settings.show_hidden = False
            self.report({'INFO'}, f"Restored {hidden_count} hidden task(s)")
        else:
            count = 0
            for task in settings.tasks:
                if task.done and not task.hidden:
                    task.hidden = True
                    count += 1
            self.report({'INFO'}, f"Hid {count} completed task(s)")

        settings.active_index = min(settings.active_index, max(0, len(settings.tasks) - 1))
        tag_redraw_all(context)
        return {'FINISHED'}


class TASKLEVELER_OT_unhide_task(Operator):
    bl_idname = "taskleveler.unhide_task"
    bl_label = "Unhide Task"

    index: IntProperty()

    def execute(self, context):
        settings = get_settings(context)
        settings.tasks[self.index].hidden = False
        return {'FINISHED'}


class TASKLEVELER_OT_unhide_all(Operator):
    bl_idname = "taskleveler.unhide_all"
    bl_label = "Unhide All"
    bl_description = "Reveal every hidden task again"

    def execute(self, context):
        settings = get_settings(context)
        count = 0
        for t in settings.tasks:
            if t.hidden:
                t.hidden = False
                count += 1
        self.report({'INFO'}, f"Unhid {count} task(s)")
        return {'FINISHED'}


class TASKLEVELER_OT_delete_hidden(Operator):
    bl_idname = "taskleveler.delete_hidden"
    bl_label = "Delete Hidden Permanently"
    bl_description = "Permanently remove all hidden tasks from the list (earned XP is kept)"

    def execute(self, context):
        settings = get_settings(context)
        removed = 0
        for i in reversed(range(len(settings.tasks))):
            if settings.tasks[i].hidden:
                settings.tasks.remove(i)
                removed += 1
        settings.active_index = max(0, min(settings.active_index, len(settings.tasks) - 1))
        self.report({'INFO'}, f"Permanently deleted {removed} hidden task(s)")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Reset operators (recovery if the level bar / state ever glitches)
# ---------------------------------------------------------------------------

class TASKLEVELER_OT_reset_xp(Operator):
    bl_idname = "taskleveler.reset_xp"
    bl_label = "Reset Level/XP"
    bl_description = "Reset XP and level back to zero. Tasks and microtasks are kept as-is."

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        settings = get_settings(context)
        settings.total_xp = 0
        tag_redraw_all(context)
        self.report({'INFO'}, "XP and level reset to 0")
        return {'FINISHED'}


class TASKLEVELER_OT_reset_all(Operator):
    bl_idname = "taskleveler.reset_all"
    bl_label = "Full Reset (XP + All Tasks)"
    bl_description = "Permanently clear everything: XP, level, every task and microtask. Cannot be undone."

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        settings = get_settings(context)
        settings.total_xp = 0
        settings.tasks.clear()
        settings.active_index = 0
        tag_redraw_all(context)
        self.report({'INFO'}, "Task Leveler fully reset")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Microtask operators
# ---------------------------------------------------------------------------

class TASKLEVELER_OT_add_microtask(Operator):
    bl_idname = "taskleveler.add_microtask"
    bl_label = "Add Microtask"

    task_index: IntProperty()

    def execute(self, context):
        settings = get_settings(context)
        if not (0 <= self.task_index < len(settings.tasks)):
            return {'CANCELLED'}
        task = settings.tasks[self.task_index]
        name = task.new_microtask_name.strip()
        if not name:
            self.report({'WARNING'}, "Type a microtask name first")
            return {'CANCELLED'}
        micro = task.microtasks.add()
        micro.name = name
        micro.xp_value = MICROTASK_XP
        task.new_microtask_name = ""
        task.active_microtask_index = len(task.microtasks) - 1
        return {'FINISHED'}


class TASKLEVELER_OT_toggle_microtask(Operator):
    bl_idname = "taskleveler.toggle_microtask"
    bl_label = "Toggle Microtask"

    task_index: IntProperty()
    micro_index: IntProperty()

    def execute(self, context):
        settings = get_settings(context)
        task = settings.tasks[self.task_index]
        micro = task.microtasks[self.micro_index]
        micro.done = not micro.done
        delta = micro.xp_value if micro.done else -micro.xp_value
        award_xp(context, settings, delta)
        sync_parent_completion(context, settings, task)
        if task.done:
            check_project_completion(settings)
        return {'FINISHED'}


class TASKLEVELER_OT_remove_microtask(Operator):
    bl_idname = "taskleveler.remove_microtask"
    bl_label = "Remove Microtask"

    task_index: IntProperty()
    micro_index: IntProperty()

    def execute(self, context):
        settings = get_settings(context)
        task = settings.tasks[self.task_index]
        if 0 <= self.micro_index < len(task.microtasks):
            task.microtasks.remove(self.micro_index)
            task.active_microtask_index = max(0, self.micro_index - 1)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Focus nudges
# ---------------------------------------------------------------------------

class TASKLEVELER_OT_nudge_popup(Operator):
    bl_idname = "taskleveler.nudge_popup"
    bl_label = "Still on track?"

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=260)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Quick check-in:", icon='TIME')
        layout.label(text="Finish a quest, or start a new small one?")

    def execute(self, context):
        return {'FINISHED'}


def nudge_timer_callback():
    global _nudge_timer_active
    try:
        settings = bpy.context.scene.task_leveler
    except Exception:
        return None

    if not settings.nudges_enabled:
        _nudge_timer_active = False
        return None

    try:
        bpy.ops.taskleveler.nudge_popup('INVOKE_DEFAULT')
    except Exception:
        pass

    return max(60, settings.nudge_interval_minutes * 60)


class TASKLEVELER_OT_toggle_nudges(Operator):
    bl_idname = "taskleveler.toggle_nudges"
    bl_label = "Toggle Focus Nudges"

    def execute(self, context):
        global _nudge_timer_active
        settings = get_settings(context)
        settings.nudges_enabled = not settings.nudges_enabled

        if settings.nudges_enabled and not _nudge_timer_active:
            interval = max(60, settings.nudge_interval_minutes * 60)
            bpy.app.timers.register(nudge_timer_callback, first_interval=interval)
            _nudge_timer_active = True
            self.report({'INFO'}, f"Nudges on — every {settings.nudge_interval_minutes} min")
        elif not settings.nudges_enabled:
            self.report({'INFO'}, "Nudges off")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

class TASKLEVELER_UL_tasks(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        if item.hidden:
            row.label(text="", icon='GHOST_ENABLED')
        else:
            op_icon = 'CHECKBOX_HLT' if item.done else 'CHECKBOX_DEHLT'
            op = row.operator(TASKLEVELER_OT_toggle_task.bl_idname, text="", icon=op_icon, emboss=False)
            op.index = index

        label = row.row()
        label.active = not item.done and not item.hidden
        if item.difficulty == 'BOSS':
            label.alert = True
        suffix = ""
        if len(item.microtasks) > 0:
            done_m = sum(1 for m in item.microtasks if m.done)
            suffix = f"  [{done_m}/{len(item.microtasks)} micro]"
        label.label(text=f"{item.name}   (+{item.xp_value} XP){suffix}")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        settings = context.scene.task_leveler
        flt_flags = []
        for item in items:
            if item.hidden and not settings.show_hidden:
                flt_flags.append(0)
            else:
                flt_flags.append(self.bitflag_filter_item)
        flt_neworder = []
        return flt_flags, flt_neworder


class TASKLEVELER_PT_panel(Panel):
    bl_label = "Task Leveler"
    bl_idname = "TASKLEVELER_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tasks"

    def draw(self, context):
        layout = self.layout
        settings = get_settings(context)

        level, xp_into, xp_needed = level_from_xp(settings.total_xp)

        hud_row = layout.row(align=True)
        hud_label = "Hide Level UI" if settings.hud_enabled else "Show Level UI"
        hud_icon = 'HIDE_ON' if settings.hud_enabled else 'HIDE_OFF'
        hud_row.operator(TASKLEVELER_OT_toggle_hud.bl_idname, text=hud_label, icon=hud_icon)
        color_row = layout.row()
        color_row.label(text="Progress Colour is global", icon='WORLD')
        color_row.operator("preferences.addon_show", text="Change", icon='PREFERENCES').module = __package__

        box = layout.box()
        row = box.row()
        row.label(text=f"Level {level}", icon='SOLO_ON')
        row.label(text=f"{xp_into} / {xp_needed} XP")
        progress_row = box.row()
        progress_row.progress(factor=(xp_into / xp_needed if xp_needed else 0), text="")

        visible_tasks = [t for t in settings.tasks if not t.hidden]
        done_count = sum(1 for t in visible_tasks if t.done)
        box.label(text=f"Quests: {done_count} / {len(visible_tasks)} complete")
        box.label(text="XP summary also appears in the Status Bar.", icon='INFO')

        layout.separator()

        row = layout.row(align=True)
        row.prop(settings, "new_task_name", text="")
        row.operator(TASKLEVELER_OT_add_task.bl_idname, text="", icon='ADD')
        layout.prop(settings, "new_task_difficulty", text="Difficulty")

        layout.template_list(
            "TASKLEVELER_UL_tasks", "", settings, "tasks", settings, "active_index", rows=6
        )

        row = layout.row(align=True)
        row.operator(TASKLEVELER_OT_remove_task.bl_idname, text="Remove Selected", icon='REMOVE')
        hidden_count = sum(1 for task in settings.tasks if task.hidden)
        hide_label = "Show Hidden Tasks" if hidden_count else "Hide Completed"
        hide_icon = 'HIDE_OFF' if hidden_count else 'HIDE_ON'
        row.operator(TASKLEVELER_OT_hide_done.bl_idname, text=hide_label, icon=hide_icon)

        if hidden_count:
            del_row = layout.row()
            del_row.alert = True
            del_row.operator(TASKLEVELER_OT_delete_hidden.bl_idname, text="Delete Hidden Permanently", icon='TRASH')

        # Microtasks for the selected task
        if 0 <= settings.active_index < len(settings.tasks):
            task = settings.tasks[settings.active_index]
            layout.separator()
            mbox = layout.box()
            mbox.label(text=f"Microtasks — {task.name}", icon='PRESET')

            mrow = mbox.row(align=True)
            mrow.prop(task, "new_microtask_name", text="")
            add_op = mrow.operator(TASKLEVELER_OT_add_microtask.bl_idname, text="", icon='ADD')
            add_op.task_index = settings.active_index

            for m_idx, micro in enumerate(task.microtasks):
                mr = mbox.row(align=True)
                m_icon = 'CHECKBOX_HLT' if micro.done else 'CHECKBOX_DEHLT'
                t_op = mr.operator(TASKLEVELER_OT_toggle_microtask.bl_idname, text="", icon=m_icon, emboss=False)
                t_op.task_index = settings.active_index
                t_op.micro_index = m_idx
                lbl = mr.row()
                lbl.active = not micro.done
                lbl.label(text=f"{micro.name}  (+{micro.xp_value} XP)")
                r_op = mr.operator(TASKLEVELER_OT_remove_microtask.bl_idname, text="", icon='X', emboss=False)
                r_op.task_index = settings.active_index
                r_op.micro_index = m_idx

        layout.separator()
        box2 = layout.box()
        box2.label(text="Feedback", icon='SETTINGS')
        box2.prop(settings, "sound_enabled")
        box2.label(text="Optional custom sound files (leave blank for built-in tones):")
        box2.label(text="Choose an audio file with the folder icon, or paste its full path.")
        sound_rows = (
            ("custom_tick_sound", "Task / Microtask Sound", 'TICK'),
            ("custom_levelup_sound", "Level-Up Sound", 'LEVELUP'),
            ("custom_project_complete_sound", "Project Complete Sound", 'PROJECT_COMPLETE'),
        )
        for property_name, label, sound_field in sound_rows:
            sound_row = box2.row(align=True)
            sound_row.prop(settings, property_name, text=label)
            clear_op = sound_row.operator(
                TASKLEVELER_OT_clear_sound_path.bl_idname,
                text="", icon='X'
            )
            clear_op.sound_field = sound_field


        nudge_row = box2.row()
        nudge_label = "Disable Focus Nudges" if settings.nudges_enabled else "Enable Focus Nudges"
        nudge_row.operator(TASKLEVELER_OT_toggle_nudges.bl_idname, text=nudge_label,
                            icon='PAUSE' if settings.nudges_enabled else 'PLAY')
        if not settings.nudges_enabled:
            box2.prop(settings, "nudge_interval_minutes")

        layout.separator()
        box3 = layout.box()
        box3.label(text="Maintenance", icon='FILE_REFRESH')
        box3.label(text="Use if the level bar or state ever glitches.", icon='ERROR')
        mrow1 = box3.row()
        mrow1.operator(TASKLEVELER_OT_reset_xp.bl_idname, icon='LOOP_BACK')
        mrow2 = box3.row()
        mrow2.alert = True
        mrow2.operator(TASKLEVELER_OT_reset_all.bl_idname, icon='TRASH')


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    TASKLEVELER_AddonPreferences,
    TASKLEVELER_Microtask,
    TASKLEVELER_Task,
    TASKLEVELER_Settings,
    TASKLEVELER_OT_celebrate,
    TASKLEVELER_OT_clear_sound_path,
    TASKLEVELER_OT_toggle_hud,
    TASKLEVELER_OT_add_task,
    TASKLEVELER_OT_remove_task,
    TASKLEVELER_OT_toggle_task,
    TASKLEVELER_OT_hide_done,
    TASKLEVELER_OT_unhide_task,
    TASKLEVELER_OT_unhide_all,
    TASKLEVELER_OT_delete_hidden,
    TASKLEVELER_OT_reset_xp,
    TASKLEVELER_OT_reset_all,
    TASKLEVELER_OT_add_microtask,
    TASKLEVELER_OT_toggle_microtask,
    TASKLEVELER_OT_remove_microtask,
    TASKLEVELER_OT_nudge_popup,
    TASKLEVELER_OT_toggle_nudges,
    TASKLEVELER_UL_tasks,
    TASKLEVELER_PT_panel,
)


def register():
    global _hud_handle
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.task_leveler = PointerProperty(type=TASKLEVELER_Settings)

    bpy.types.STATUSBAR_HT_header.append(draw_status_bar)

    _hud_handle = bpy.types.SpaceView3D.draw_handler_add(
        draw_viewport_hud, (), 'WINDOW', 'POST_PIXEL'
    )


def unregister():
    global _nudge_timer_active, _hud_handle, _hud_anim
    _hud_anim = None
    if bpy.app.timers.is_registered(_hud_animation_tick):
        bpy.app.timers.unregister(_hud_animation_tick)

    if _hud_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_hud_handle, 'WINDOW')
        _hud_handle = None

    bpy.types.STATUSBAR_HT_header.remove(draw_status_bar)

    if bpy.app.timers.is_registered(nudge_timer_callback):
        bpy.app.timers.unregister(nudge_timer_callback)
    _nudge_timer_active = False

    del bpy.types.Scene.task_leveler
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
